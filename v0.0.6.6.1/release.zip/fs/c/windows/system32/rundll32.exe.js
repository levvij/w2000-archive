const window = new Window("Run", 350, 150);

window.render(ui => {
	
});
UI.extend("StackPanel", env => {
	return env.element("ui-stack");
});
UI.extend("Container", env => {
	return env.element("ui-container");
});
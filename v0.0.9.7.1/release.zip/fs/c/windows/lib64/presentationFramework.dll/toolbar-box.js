UI.extend("ToolbarBox", env => {
	return env.element("ui-toolbar-box");
});
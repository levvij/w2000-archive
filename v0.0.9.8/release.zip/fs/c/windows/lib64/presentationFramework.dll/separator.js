UI.extend("Separator", env => {
	return env.element("ui-separator");
});
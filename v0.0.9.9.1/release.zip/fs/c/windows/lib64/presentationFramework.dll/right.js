UI.extend("Right", env => {
	return env.element("ui-right");
});
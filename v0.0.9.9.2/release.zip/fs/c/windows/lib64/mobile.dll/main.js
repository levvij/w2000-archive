document.body.setAttribute("webapp", "");

const bottomBar = document.createElement("m-bottom");
bottomBar.textContent = "Aaaaa a a a a a a a a a a a a a a a a a a a a a a a a a a a  aa a a ";

document.querySelector("screen").appendChild(bottomBar);
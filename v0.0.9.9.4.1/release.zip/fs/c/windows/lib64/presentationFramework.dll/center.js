UI.extend("Center", env => {
	return env.element("ui-center");
});
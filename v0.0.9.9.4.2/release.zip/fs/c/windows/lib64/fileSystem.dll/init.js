DLL.export("fs", await NTFS());
Path.creators = fs.creators;
DLL.export("Environment", {
	get path() {
		return config.path;
	}
})
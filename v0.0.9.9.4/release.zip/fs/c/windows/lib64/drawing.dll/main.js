DLL.private.key = {};
DLL.export("Graphics", {});